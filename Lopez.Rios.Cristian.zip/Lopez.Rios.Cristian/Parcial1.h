
typedef struct
{
    int id;
    int dni;
    char nombre[51];
    char apellido[51];
    int cantAlquileres;
    int estado;

}eCliente;


typedef struct
{
    int idAlquiler;
    int idArticulo;
    char operador[51];
    int idEquipo;
    char equipo[51];
    int tiempoEstimado;//horas de alquiler al dar de alta
    int tiempoReal;//horas que duro el alquiler
    int estado;
    char estadoAlquiler[51];
}eAlquiler;


typedef struct
{
    int idEquipo;
    char descripcion[51];
    float precioPorHora;

}eEquipo;





/*
5 fin alquiler
muestre
if(te <= tr) = cobrar precio por hora
precio alquiler
total alquiler
te = tr
tr < te
if(tr > te) = cobrar multa, precio por hora + excedente(30%)
*/

void iniciarEstadoCliente(eCliente cliente[], int tamC);
void iniciarEstadoAlquiler(eAlquiler alquiler[], int tamA);

void cargarClientes(eCliente cliente[]);
void cargarAlquiler(eAlquiler alquiler[]);

void mostrarCliente(eCliente cliente[], int tamC);
void mostrarAlquileres(eCliente cliente[], eAlquiler alquiler[], int tamC, int tamA);
void mostrarAlquilerCliente(eCliente cliente[], eAlquiler alquiler[], int tamC, int tamA);

void altaCliente(eCliente cliente[], int tamC, int espacioLibre);
void altaAlquiler(eAlquiler alquiler[], eCliente cliente[], int tamC, int tamA);

int encontrarEspacioLibre(eCliente cliente[], int tam);

void borrarCliente(eCliente cliente[], int tamC);
void modificarCliente(eCliente cliente[], int tamC);

void bajaAlquiler(eAlquiler alquiler[], eCliente cliente[], int tamC, int tamA);

void ClienteMayorAlquileres(eCliente cliente[], eAlquiler alquiler[], int tamC, int tamA);
void equipoMasAlquilado(eCliente clliente[], eAlquiler alquiler[], int tamC, int tamA);
void tiempoRealPromedio(eCliente cliente[], eAlquiler alquiler[], int tamC, int tamA);


void cargarEquipo(eEquipo equipo[]);

void mostrarEquipo(eEquipo equipo[]);

void precioPorTiempo(eAlquiler alquiler[], eEquipo equipo[], int tamA, int tamE);
