#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <conio.h>
#include "Parcial1.h"

/** \brief Inicia los estados de la estructura cliente en cero
 *
 * \param array de la estructura eCliente
 * \param tama�o del array de clientes
 * \return void
 *
 */


void iniciarEstadoCliente(eCliente cliente[], int tamC)
{
    int i;
    for(i = 0; i < tamC; i++)
    {
        cliente[i].estado = 0;
        cliente[i].cantAlquileres = 0;

    }
}


/** \brief Inicia los estados de la estructura alquiler en cero
 *
 * \param array de la estructura eAlquiler
 * \param tama�o del array de alquileres
 * \return void
 *
 */


void iniciarEstadoAlquiler(eAlquiler alquiler[], int tamA)
{
    int j;
    for(j = 0; j < tamA; j++)
    {
        alquiler[j].estado = 0;
    }

}


/** \brief hardcodea clientes
 *
 * \param array de la estructura eCliente
 * \return void
 *
 */


void cargarClientes(eCliente cliente[])
{
    int id[10] = {100,101,102,103,104,105,106,107,108,109};
    int dni[10] = {1111,2222,3333,4444,5555,6666,7777,8888,9999,1000};
    char nombres[10][51] = {"Juan", "Maria", "Pedro", "Luis", "Romina", "Jose", "Andrea", "Patricia", "Luciano", "Camila"};
    char apellidos[10][51] = {"Rios", "Barraza", "Quiroga", "Martines", "Lobato", "Cardena", "Gimenez", "Mendez", "Paez", "Iud"};

    int i;

    for(i = 0; i < 10; i++)
    {
        cliente[i].cantAlquileres++;
        cliente[i].estado = 1;
        cliente[i].id = id[i];
        cliente[i].dni = dni[i];
        strcpy(cliente[i].nombre, nombres[i]);
        strcpy(cliente[i].apellido, apellidos[i]);

    }
}


/** \brief hardcodea alquileres
 *
 * \param array de la estructura eAlquiler
 * \return void
 *
 */


void cargarAlquiler(eAlquiler alquiler[])
{
    int idAlquiler[10] = {100,101,102,103,104,105,106,107,108,109};
    char operador[10][51] = {"AA", "BB", "CC", "DD", "EE", "FF", "GG", "HH", "II", "JJ"};
    char equipo[10][51] = {"Amoladora", "Mezcladora", "Taladro", "Mezcladora", "Amoladora", "Taladro", "Mezcladora", "Taladro", "Amoladora", "Mezcladora"};
    int tiempo[10] = {9,7,7,6,10,5,8,6,15,13};
    int tiempoReal[10] = {1,2,3,4,5,6,10,8,6,5};
    int idArticulo[10] = {200,201,202,203,204,205,206,207,208,209};

    int j;

    for(j = 0; j < 10; j++)
    {
        alquiler[j].idAlquiler = idAlquiler[j];
        strcpy(alquiler[j].operador, operador[j]);
        alquiler[j].tiempoEstimado = tiempo[j];
        strcpy(alquiler[j].equipo,equipo[j]);
        alquiler[j].estado = 1;
        alquiler[j].tiempoReal = tiempoReal[j];
        alquiler[j].idArticulo = idArticulo[j];
        strcpy(alquiler[j].estadoAlquiler,"Finalizado");



    }
}


/** \brief muestra los clientes ingresados
 *
 * \param array de la estructura eCliente
 * \param tama�o del array de clientes
 * \return void
 *
 */


void mostrarCliente(eCliente cliente[], int tamC)
{
    int i;

    for(i = 0; i < tamC; i++)
    {
        if(cliente[i].estado == 1)
        {
            printf("ID : %d - DNI : %d - Nombre : %s - Apellido : %s \n", cliente[i].id, cliente[i].dni, cliente[i].nombre, cliente[i].apellido);
        }
    }
}


/** \brief muestra los alquileres ingresados
 *
 * \param array de la estructura eCliente
 * \param array de la estructura eAlquiler
 * \param tama�o del array de clientes
 * \param tama�o del array de alquileres
 * \return void
 *
 */


void mostrarAlquileres(eCliente cliente[], eAlquiler alquiler[], int tamC, int tamA)
{
    int i,j;

    for(j = 0; j < tamA; j++)
    {
        if(alquiler[j].estado == 1)
        {
            printf("ID de alquiler : %d - Operador : %s - Equipo : %s - Tiempo Promedio : %d - Estado : %s - Cliente : ", alquiler[j].idArticulo, alquiler[j].operador, alquiler[j].equipo, alquiler[j].tiempoEstimado, alquiler[j].estadoAlquiler);

            for(i = 0; i < tamC; i++)
            {
                if(alquiler[j].idAlquiler == cliente[i].id)
                {
                    printf("%s \n", cliente[i].nombre);
                }
            }
        }

    }
}



/** \brief da de alta un cliente
 *
 * \param array de la estructura eCliente
 * \param tama�o del array de clientes
 * \param indice libre en el array
 * \return void
 *
 */


void altaCliente(eCliente cliente[], int tamC, int espacioLibre)
{

    //int i;

    if(espacioLibre != -1)
    {
        printf("Ingrese nombre :");
        fflush(stdin);
        gets(cliente[espacioLibre].nombre);

        printf("Ingrese apellido :");
        fflush(stdin);
        gets(cliente[espacioLibre].apellido);

        printf("Ingrese dni:");
        scanf("%d", &cliente[espacioLibre].dni);

        cliente[espacioLibre].estado = 1;

        cliente[espacioLibre].id = espacioLibre + 100;


    }

    else
    {
        printf("No queda espacio!!");
    }




    mostrarCliente(cliente, tamC);
//    for(i = 0; i < tamC; i++)
//    {
//        if(cliente[i].estado == 1)
//        {
//            printf("ID : %d - DNI : %d - Nombre : %s - Apellido : %s \n", cliente[i].id, cliente[i].dni, cliente[i].nombre, cliente[i].apellido);
//        }
//
//    }


}


/** \brief da de alta un alquiler
 *
 * \param array de la estructura eAlquiler
 * \param array de la estructura eCliente
 * \param tama�o del array de clientes
 * \param tama�o del array de alquileres
 * \return void
 *
 */


void altaAlquiler(eAlquiler alquiler[], eCliente cliente[], int tamC, int tamA)
{

    int i,j;
    int opcionEquipo;


    for(j = 0; j < tamA; j++)
    {
        if(alquiler[j].estado == 0)
        {
            mostrarCliente(cliente, tamC);

//            for(i = 0; i < tamC; i++)
//            {
//                if(cliente[i].estado == 1)
//                    {
//                        printf("\nID : %d - DNI : %d - Nombre : %s - Apellido : %s \n", cliente[i].id, cliente[i].dni, cliente[i].nombre, cliente[i].apellido);
//                    }
//            }


            printf("\nIngrese el ID del cliente que desea alquilar un equipo : ");
            scanf("%d", &alquiler[j].idAlquiler);


            for(i = 0; i < tamC; i++)
            {


                if(cliente[i].estado == 1 && cliente[i].id == alquiler[j].idAlquiler)
                {
                    cliente[i].cantAlquileres++;

                    printf("Ingrese Operador :");
                    fflush(stdin);
                    gets(alquiler[j].operador);

                    printf("Ingrese equipo (1-Amoladora / 2-Mezcladora / 3-Taladro /) : ");
                    scanf("%d", &alquiler[j].idEquipo);

                    opcionEquipo = alquiler[j].idEquipo;

                    switch(opcionEquipo)
                    {
                        case 1:
                            strcpy(alquiler[j].equipo, "Amoladora");
                            break;
                        case 2:
                            strcpy(alquiler[j].equipo, "Mezcladora");
                            break;
                        case 3:
                            strcpy(alquiler[j].equipo, "Taladro");
                            break;
                    }

                    alquiler[j].idArticulo = j + 200;

                    printf("Ingrese horas de alquiler: ");
                    scanf("%d", &alquiler[j].tiempoEstimado);

                    strcpy(alquiler[j].estadoAlquiler, "Alquilado");

                    alquiler[j].estado = 1;




                }


            }

            break;

        }

    }



    if(j == tamA)
    {
        printf("No queda espacio!!\n");
    }

    for(i = 0; i < tamC; i++)
    {
        if(cliente[i].estado == 1)
        {
            for(j = 0; j < tamA; j++)
            {
                if(alquiler[j].idAlquiler == cliente[i].id)
                {
                    printf("Cantidad de alquileres de %s : %d \n", cliente[i].nombre, cliente[i].cantAlquileres);
                    break;
                }
            }
        }
    }


    mostrarAlquileres(cliente, alquiler, tamC, tamA);


//    for(j = 0; j < tamA; j++)
//    {
//        if(alquiler[j].estado == 1)
//        {
//            printf("ID de alquiler : %d - Operador : %s - Equipo : %s - Tiempo Promedio : %d - Estado : %s - Cliente : ", alquiler[j].idArticulo, alquiler[j].operador, alquiler[j].equipo, alquiler[j].tiempoEstimado, alquiler[j].estadoAlquiler);
//
//            for(i = 0; i < tamC; i++)
//            {
//                if(alquiler[j].idAlquiler == cliente[i].id)
//                {
//                    printf("%s \n", cliente[i].nombre);
//                }
//            }
//        }
//
//    }


}


/** \brief da de baja un alquiler
 *
 * \param array de la estructura eAlquiler
 * \param array de la estructura eCliente
 * \param tama�o del array de clientes
 * \param tama�o del array de alquileres
 * \return void
 *
 */


void bajaAlquiler(eAlquiler alquiler[], eCliente cliente[], int tamC, int tamA)
{
    int i,j;
    int idBajaAlquiler;


    mostrarAlquileres(cliente, alquiler, tamC, tamA);


//    for(j = 0; j < tamA; j++)
//    {
//        if(alquiler[j].estado == 1)
//        {
//            printf("ID de alquiler : %d - Operador : %s - Equipo : %s - Tiempo Promedio : %d - Estado : %s - Cliente : ", alquiler[j].idArticulo, alquiler[j].operador, alquiler[j].equipo, alquiler[j].tiempoEstimado, alquiler[j].estadoAlquiler);
//
//            for(i = 0; i < tamC; i++)
//            {
//                if(alquiler[j].idAlquiler == cliente[i].id)
//                {
//                    printf("%s \n", cliente[i].nombre);
//                }
//            }
//        }
//
//    }





    printf("\nIngrese el ID del alquiler a finalizar : ");
    scanf("%d", &idBajaAlquiler);

    for(j = 0; j < tamA; j++)
    {

        if(alquiler[j].idArticulo == idBajaAlquiler && alquiler[j].estado == 1)
        {
            printf("Ingrese el tiempo que duro el alquiler : ");
            scanf("%d", &alquiler[j].tiempoReal);

            strcpy(alquiler[j].estadoAlquiler, "Finalizado");

        }

//        if(strcmp(alquiler[j].estadoAlquiler,"Finalizado") == 0)
//        {
//            alquiler[j].estado = 0;
//        }

    }




    for(j = 0; j < tamA; j++)
    {
        if(alquiler[j].estado == 1)
        {
            printf("ID de alquiler : %d - Operador : %s - Equipo : %s - Tiempo promedio : %d - Tiempo Real : %d - Estado : %s - Cliente : ", alquiler[j].idArticulo, alquiler[j].operador, alquiler[j].equipo, alquiler[j].tiempoEstimado, alquiler[j].tiempoReal, alquiler[j].estadoAlquiler);

            for(i = 0; i < tamC; i++)
            {
                if(alquiler[j].idAlquiler == cliente[i].id)
                {
                    printf("%s \n", cliente[i].nombre);
                }
            }
        }

    }
}



/** \brief encuentra un espacio libre para un cliente en el array
 *
 * \param array de la estructura eCliente
 * \param tama�o del array
 * \return retorna indice libre como entero
 *
 */

int encontrarEspacioLibre(eCliente cliente[], int tam)
{
    int i;
    int indiceLibre = -1;

    for(i = 0; i < tam; i++)
    {
        if(cliente[i].estado == 0 )
        {
            indiceLibre = i;
            break;
        }

    }

    return indiceLibre;
}


/** \brief borra un cliente
 *
 * \param array de la estructura eCliente
 * \param tama�o del array de clientes
 * \return void
 *
 */


void borrarCliente(eCliente cliente[], int tamC)
{
    int i, idBaja;

    char opcion;


    mostrarCliente(cliente, tamC);

    printf("Ingrese el ID del cliente que desea dar de baja : ");
    scanf("%d", &idBaja);

    for(i = 0; i < tamC; i++)
    {
        if(cliente[i].estado == 1 && cliente[i].id == idBaja)
        {

            printf("\nEsta seguro que desea eliminar este cliente? s/n \n");
            fflush(stdin);
            opcion = tolower(getche());

            if(opcion == 's')
            {
                cliente[i].estado = 0;
                printf("\nCliente eliminado!!\n");
                break;
            }
            else
            {
                printf("\nAccion cancelada!!\n");
                break;
            }


        }
        else if(cliente[i].estado == 0 && cliente[i].id != idBaja)
        {
            printf("\nCliente inexistente!!\n");
            break;
        }

    }



}



/** \brief modifica un cliente
 *
 * \param array de la estructura eCliente
 * \param tama�o del array de clientes
 * \return void
 *
 */

void modificarCliente(eCliente cliente[], int tamC)
{
    int i, idModif;
    char opcion;

    mostrarCliente(cliente, tamC);

    printf("\nIngrese el ID del cliente a modificar : ");
    scanf("%d", &idModif);

    for(i = 0 ;i < tamC; i++)
    {
        if(cliente[i].estado == 1 && cliente[i].id == idModif)
        {
            printf("\nDesea modificar este cliente? s/n \n");
            opcion = tolower(getche());

            if(opcion == 's')
            {
                printf("\nIngrese nombre :");
                fflush(stdin);
                gets(cliente[i].nombre);

                printf("\nIngrese apellido :");
                fflush(stdin);
                gets(cliente[i].apellido);

                break;

            }
            else
            {
                printf("\nAccion cancelada!!\n");
            }
        }

        else if(cliente[i].estado == 0 && cliente[i].id != idModif)
        {
            printf("\nCliente inexistente!!\n");
            break;
        }

    }



}


/** \brief muestra los alquileres por cliente
 *
 * \param array de la estructura eCliente
 * \param array de la estructura eAlquiler
 * \param tama�o del array de clientes
 * \param tama�o del array de alquileres
 * \return void
 *
 */


void mostrarAlquilerCliente(eCliente cliente[], eAlquiler alquiler[], int tamC, int tamA)
{
    int i,j;

    printf("Alquileres por cliente : \n");

    for(i = 0; i < tamC; i++)
    {
        if(cliente[i].estado == 1)
        {
            printf("ID : %d - Nombre : %s - Apellido : %s - Alquileres : ", cliente[i].id, cliente[i].nombre, cliente[i].apellido);

            for(j = 0; j < tamA; j++)
            {
                if(alquiler[j].estado == 1)
                {

                    if(alquiler[j].idAlquiler == cliente[i].id)
                    {
                        printf("%s - ", alquiler[j].equipo);
                    }

                }
            }
            printf("\n");
        }
    }
}


/** \brief muestra el cliente con mayor numero de alquileres
 *
 * \param array de la estructura eCliente
 * \param array de la estructura eAlquiler
 * \param tama�o del array de clientes
 * \param tama�o del array de alquileres
 * \return void
 *
 */


void ClienteMayorAlquileres(eCliente cliente[], eAlquiler alquiler[], int tamC, int tamA)
{
    int i;
    int flag = 0;
    int maximo = 0;

    for(i = 0; i < tamC; i++)
    {
        if(flag == 0)
        {
            maximo = cliente[i].cantAlquileres;
            flag = 1;
        }
        else
        {
            if(cliente[i].cantAlquileres > maximo)
            {
                maximo = cliente[i].cantAlquileres;
            }
        }

    }

    printf("Cliente con mas alquileres : \n");

     for(i = 0; i < tamC; i++)
    {
        if(maximo == cliente[i].cantAlquileres && cliente[i].estado == 1)
        {
            printf("Nombre : %s - Apellido : %s - Numero maximo de alquileres : %d \n", cliente[i].nombre, cliente[i].apellido, maximo);
        }
    }


}


/** \brief muestra el nombre del equipo mas alquilado
 *
 * \param array de la estructura eCliente
 * \param array de la estructura eAlquiler
 * \param tama�o del array de clientes
 * \param tama�o del array de alquileres
 * \return void
 *
 */


void equipoMasAlquilado(eCliente clliente[], eAlquiler alquiler[], int tamC, int tamA)
{
    int j;
    int acumulador[3] = {0};
    int maximo;


    for(j = 0; j < tamA; j++)
    {
        if(alquiler[j].estado == 1)
        {
            if(strcmp(alquiler[j].equipo,"Amoladora") == 0)
            {
                acumulador[0]++;
            }
            else
            {
                if(strcmp(alquiler[j].equipo,"Mezcladora") == 0)
                {
                    acumulador[1]++;
                }
                else
                {
                    if(strcmp(alquiler[j].equipo,"Taladro") == 0)
                    {
                        acumulador[2]++;
                    }
                }
            }
        }
    }

    for(j = 0; j < 3; j++)
    {
        if(j == 0)
        {
            maximo = acumulador[j];
        }
        else
        {
            if(acumulador[j] > maximo)
            {
                maximo = acumulador[j];
            }
        }
    }

    if(maximo == acumulador[0])
    {
        printf("El equipo mas alquilado es la Amoladora \n");
    }
    else
    {
        if(maximo == acumulador[1])
        {
            printf("El equipo mas alquilado es la Mezcladora \n");
        }
        else
        {
            printf("El equipo mas alquilado es el Taladro \n");
        }


    }


}


/** \brief muestra el promedio del tiempo real total
 *
 * \param array de la estructura eCliente
 * \param array de la estructura eAlquiler
 * \param tama�o del array de clientes
 * \param tama�o del array de alquileres
 * \return void
 *
 */


void tiempoRealPromedio(eCliente cliente[], eAlquiler alquiler[], int tamC, int tamA)
{
    int j;
    int acum = 0;
    int AlqTotales = 0;
    float TrealPromedio;


    for(j = 0; j < tamA; j++)
    {
         if(strcmp(alquiler[j].estadoAlquiler, "Finalizado") == 0)
         {
             acum += alquiler[j].tiempoReal;
             AlqTotales++;
         }

    }

    TrealPromedio = acum / (float)AlqTotales;

    printf("Tiempo real promedio : %f\n", TrealPromedio);


}


/** \brief
 *
 * \param
 * \param
 * \return
 *
 */


void cargarEquipo(eEquipo equipo[])
{
    // Amoladora 5
    //  Mezcladora 10
    // taladro 15
    int idEquipo[10] = {100,101,102,103,104,105,106,107,108,109};
    char Descripcion[10][51] = {"AA", "BB", "CC", "DD", "EE", "FF", "GG", "HH", "II", "JJ"};
    float precioPorHora[10] = {5,10,15,10,5,15,15,10,5,5};//cuanto vale cada equipo

    int k;

    for(k = 0; k < 10; k++)
    {
        equipo[k].idEquipo = idEquipo[k];
        strcpy(equipo[k].descripcion, Descripcion[k]);
        equipo[k].precioPorHora = precioPorHora[k];

    }

}


void mostrarEquipo(eEquipo equipo[])
{
    int k;

    for(k = 0; k < 10; k++)
    {
        printf("ID Equipo : %d - Descripcion : %s - Precio de cada equipo : %f \n", equipo[k].idEquipo, equipo[k].descripcion, equipo[k].precioPorHora);
    }
}






void precioPorTiempo(eAlquiler alquiler[], eEquipo equipo[], int tamA, int tamE)
{
    int j,k;
    float totalAlquiler;
    int precioTiempoReal;
    int precioTiempoEstimado;
    int precioTiempoTotal;
    int excedente;
    int flagEquipo = 0;



    for(j = 0; j < tamA; j++)
    {
        if(alquiler[j].estado == 1)
        {
            precioTiempoEstimado = alquiler[j].tiempoEstimado * 4;
        }

        if(strcmp(alquiler[j].estadoAlquiler, "Finalizado") == 0)
        {
            precioTiempoReal = alquiler[j].tiempoReal * 10;
        }

        precioTiempoTotal = precioTiempoEstimado + precioTiempoReal;
    }


    for(j = 0; j < tamA; j++)
    {
        if(alquiler[j].tiempoEstimado >= alquiler[j].tiempoReal)
        {
            for(k = 0; k < tamE; k++)
            {
                 //cobrar precio por hora
                 totalAlquiler = equipo[k].precioPorHora * precioTiempoTotal;
                 flagEquipo = 1;
            }


        }

        else
        {
            if(alquiler[j].tiempoReal > alquiler[j].tiempoEstimado )
            {
                //cobrar multa, precio por hora + excedente(30%)
                for(k = 0; k < tamE; k++)
                {
                    excedente = totalAlquiler * 30 / 100;
                    totalAlquiler = totalAlquiler + excedente;
                    flagEquipo = 2;
                }

            }
        }

    }


    if(flagEquipo != 0)
    {
        printf("\ntotal alquiler : %f\n\n", totalAlquiler);
    }


//    for(j = 0; j < 3; j++)
//    {
//        if(alquiler[j].estado != 0)
//        {
//            for(k = 0; k < tamE; k++)
//                {
//                    if(flagEquipo != 0)
//                    printf("total alquiler : %f", totalAlquiler);
//                }
//        }
//    }


}
