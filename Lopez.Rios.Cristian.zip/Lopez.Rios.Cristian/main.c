#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <conio.h>
#include "Parcial1.h"

#define AMOLADORA 1
#define MEZCLADORA 2
#define TALADRO 3

#define ALQUILADO 1
#define FINALIZADO 0

#define TAMC 20
#define TAMA 20
#define TAME 20






int main()
{
    //int espacioLibre;

    char seguir = 's';

    int opcion;

    eAlquiler alquiler[20];
    eCliente cliente[20];
    eEquipo equipo[20];

    iniciarEstadoCliente(cliente, TAMC);
    iniciarEstadoAlquiler(alquiler, TAMA);


    cargarClientes(cliente);
    cargarAlquiler(alquiler);
    cargarEquipo(equipo);


    do
    {
        opcion = 0;

        printf("1 - Alta clientes \n");
        printf("2 - Modificar datos del cliente \n");
        printf("3 - Baja del cliente\n");
        printf("4 - Nuevo alquiler \n");
        printf("5 - Fin alquiler \n");
        printf("6 - Informar \n");
        printf("7 - Salir \n");

        printf("Ingrese una opcion : ");
        scanf("%d", &opcion);

        while(opcion < 1 || opcion > 7)
        {
            printf("Error, opcion no valida, Reingrese : ");
            scanf("%d", &opcion);
        }

        switch(opcion)
        {
            case 1 :

                //espacioLibre = encontrarEspacioLibre(cliente, TAMC);


                mostrarCliente(cliente, TAMC);

                //altaCliente(cliente, TAMC,espacioLibre);


                system("pause");
                system("cls");

                break;
            case 2 :

                modificarCliente(cliente, TAMC);

                system("pause");
                system("cls");

                break;
            case 3 :

                borrarCliente(cliente, TAMC);

                system("pause");
                system("cls");

                break;
            case 4 :


                mostrarAlquileres(cliente, alquiler, TAMC, TAMA);



                //altaAlquiler(alquiler, cliente, TAMC, TAMA);


                system("pause");
                system("cls");

                break;
            case 5 :

                bajaAlquiler(alquiler, cliente, TAMC, TAMA);
                mostrarEquipo(equipo);
                precioPorTiempo(alquiler, equipo, TAMA, TAME);

                system("pause");
                system("cls");

                break;


            case 6 :





                        printf("\n");

                        ClienteMayorAlquileres(cliente, alquiler, TAMC, TAMA);

                        printf("\n");

                        equipoMasAlquilado(cliente, alquiler, TAMC, TAMA);

                        printf("\n");

                        tiempoRealPromedio(cliente, alquiler, TAMC, TAMA);

                        printf("\n");

                        mostrarAlquilerCliente(cliente, alquiler, TAMC, TAMA);

                        system("pause");










                system("pause");
                system("cls");

                break;
            case 7 :
                seguir = 'n';

                break;


        }




    }while(seguir != 'n');




    return 0;
}
